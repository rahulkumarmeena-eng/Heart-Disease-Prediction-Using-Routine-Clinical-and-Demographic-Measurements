# Cardiovascular Disease Prediction: Logistic Regression (from scratch) vs. Random Forest

ES 678 course project, IIT Gandhinagar. Author: Rahul Kumar Meena (26210115).

This project asks whether routine examination data (age, height, weight, blood pressure, cholesterol and glucose grades, smoking, alcohol, physical activity) can predict cardiovascular disease. It also asks whether a random forest predicts it better than logistic regression, especially in recall. Three models are compared on the same held-out test set:

1. **Logistic regression from scratch**: NumPy, L2 penalty, full-batch Adam, early stopping on validation loss
2. **Logistic regression in scikit-learn**: L-BFGS, used to check the scratch implementation
3. **Random forest**: 300 trees, tuned depth and leaf size

## Results (test set, threshold 0.5)

| Model | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Logistic regression (scratch) | 72.5 | 76.2 | 64.5 | 69.8 |
| Logistic regression (scikit-learn) | 72.6 | 76.2 | 64.6 | 69.8 |
| Random forest | 72.9 | 74.8 | 67.8 | 71.2 |

The full results, including ROC-AUC, are written to `cardio_model_comparison.csv` when you run the script. The figures are in `results/`.

## Repository layout

```
src/cardio_classification.py   full pipeline: preprocessing, 3 models, tuning, evaluation, figures
data/README.md                 how to get the dataset (data are not included)
results/                       figures produced by the run reported in the paper
requirements.txt
```

## Reproducing the results

1. **Get the data.** Download `cardio_data_processed.csv` from Kaggle:
   <https://www.kaggle.com/datasets/colewelkins/cardiovascular-disease>.
   This is a processed version of the Cardiovascular Disease dataset by S. Ulianova:
   <https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset>.
   Put the file at `data/cardio_data_processed.csv`.
2. **Install the dependencies** (Python 3.10 or newer):
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the script:**
   ```bash
   python src/cardio_classification.py data/cardio_data_processed.csv
   ```
   On Google Colab, upload the CSV to `/content/` and run the script. It finds the file there automatically.

The script prints the data checks, tuning logs and test metrics. It writes the following files to the working directory: `scratch_logistic_history.csv`, `cardio_model_comparison.csv`, `scratch_loss.png`, `scratch_accuracy.png`, `feature_importance.png`, `model_comparison.png` and `correlation_heatmap.png`. A full run takes a few minutes on Colab.

### Reproducibility notes
- **Columns dropped:** `id`, `index`, `age.1`, `age` (in days; `age_years` is kept) and `bp_category_encoded` (it duplicates `bp_category`).
- **Split:** stratified, 70% train / 15% validation / 15% test. The test set is split off first; then 17.647% of the remainder becomes the validation set. Both splits use `random_state=42`.
- **Preprocessing:** `StandardScaler` for numerical features and `OneHotEncoder` for `bp_category`. Both are fitted on the training split only.
- **Scratch logistic regression:**
  - Weights start at zero.
  - Grid: learning rate ∈ {0.001, 0.003, 0.01}, λ ∈ {0.001, 0.01, 0.1, 1}.
  - Tuning runs use patience 100 and at most 1500 epochs. The final model is retrained with patience 150 and at most 2000 epochs.
  - Selection criterion: lowest validation loss.
- **scikit-learn logistic regression:** C ∈ {0.01, 0.1, 1, 10, 100}, selected by validation accuracy.
- **Random forest:** `max_depth` ∈ {20, None} × `min_samples_leaf` ∈ {1, 3}, with `n_estimators=300` and `random_state=42`. Selected by validation accuracy.
- **Test set:** used once, for the final comparison. All models use a decision threshold of 0.5.
- **Expected run-to-run variation:** the random forest uses `n_jobs=-1`, but its results are deterministic for a fixed `random_state`. Small differences (around 0.1 points) can occur across scikit-learn versions.

## AI-use disclosure
Claude (Anthropic) was used to help draft the written report, format it in LaTeX, and write this README from the author's code and output figures. It also made small portability edits to the script: a command-line data path in place of the hard-coded Colab path, and `print` in place of `display`. The modelling code and the experiment run were done by the author in Google Colab. The author checked the reported numbers against the outputs of that run.

## References
- S. Ulianova, *Cardiovascular Disease Dataset*, Kaggle, 2019.
- C. Welkins, *Cardiovascular Disease* (processed), Kaggle.
- F. Pedregosa et al., "Scikit-learn: Machine Learning in Python," *JMLR* 12, 2011.
- D. P. Kingma and J. Ba, "Adam: A Method for Stochastic Optimization," *ICLR*, 2015.
- L. Breiman, "Random Forests," *Machine Learning* 45(1), 2001.
- C. Strobl et al., "Bias in Random Forest Variable Importance Measures," *BMC Bioinformatics* 8:25, 2007.

The data are public and are not redistributed here. This repository contains no private data, credentials or API keys.
