# Data

This folder is empty on purpose. The dataset is public but is not redistributed in this repository.

Download `cardio_data_processed.csv` from
<https://www.kaggle.com/datasets/colewelkins/cardiovascular-disease>
and place it here as `data/cardio_data_processed.csv`.

Each row is one patient examination (about 68k rows). The target column is `cardio` (1 = cardiovascular disease present).
