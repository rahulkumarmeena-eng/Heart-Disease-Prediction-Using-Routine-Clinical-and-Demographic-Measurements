# -*- coding: utf-8 -*-
"""Cardiovascular disease classification: scratch logistic regression vs.
scikit-learn logistic regression vs. random forest (ES 678 course project).

Originally developed in Google Colab. Usage:
    python src/cardio_classification.py [path/to/cardio_data_processed.csv]
Default data path: data/cardio_data_processed.csv (or /content/... on Colab).
"""

import os
import sys
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from scipy.special import expit

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score
)

start = time.time()

if len(sys.argv) > 1 and not sys.argv[1].startswith('-'):
    path = sys.argv[1]
elif os.path.exists('/content/cardio_data_processed.csv'):
    path = '/content/cardio_data_processed.csv'   # Google Colab
else:
    path = 'data/cardio_data_processed.csv'

data = pd.read_csv(path)

print("Dataset shape:", data.shape)

print("\nColumn names:")
print(list(enumerate(data.columns)))

print("\nFirst five rows:")
print(data.head())

print("\nMissing values:")
print(data.isnull().sum())

print("\nDataset information:")
print(data.info())

# Remove unnecessary columns
drop_cols = ['id', 'index', 'age.1']

data = data.drop(
    columns=drop_cols,
    errors='ignore'
)

# Avoid duplicate age information
if 'age_years' in data.columns and 'age' in data.columns:
    data = data.drop(columns=['age'])

# Avoid duplicate BP category representation
if 'bp_category' in data.columns and 'bp_category_encoded' in data.columns:
    data = data.drop(columns=['bp_category_encoded'])

# Separate input and target
y = data['cardio'].astype(int)

X = data.drop(columns=['cardio'])

# Identify categorical and numerical features
categorical_features = X.select_dtypes(
    include=['object', 'category', 'bool']
).columns.tolist()

numerical_features = X.select_dtypes(
    include=np.number
).columns.tolist()

print("Numerical features:", numerical_features)
print("Categorical features:", categorical_features)

print("\nTarget distribution:")
print(y.value_counts())

print("\nTarget percentages:")
print(y.value_counts(normalize=True) * 100)

# First separate test data
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X,
    y,
    test_size=0.15,
    random_state=42,
    stratify=y
)

# Separate training and validation data
X_train, X_val, y_train, y_val = train_test_split(
    X_train_val,
    y_train_val,
    test_size=0.17647,
    random_state=42,
    stratify=y_train_val
)

print("Training samples:", len(X_train))
print("Validation samples:", len(X_val))
print("Testing samples:", len(X_test))

print("\nTraining distribution:")
print(y_train.value_counts(normalize=True))

print("\nValidation distribution:")
print(y_val.value_counts(normalize=True))

print("\nTesting distribution:")
print(y_test.value_counts(normalize=True))

# Create preprocessing pipeline
transformers = []

if numerical_features:
    transformers.append(
        ('num', StandardScaler(), numerical_features)
    )

if categorical_features:
    transformers.append(
        ('cat', OneHotEncoder(
            handle_unknown='ignore',
            sparse_output=False
        ), categorical_features)
    )

preprocessor = ColumnTransformer(
    transformers=transformers,
    remainder='drop'
)

# Fit only on training data
X_train_processed = preprocessor.fit_transform(X_train)

# Transform validation and testing
X_val_processed = preprocessor.transform(X_val)
X_test_processed = preprocessor.transform(X_test)

# Convert to numerical arrays
Xtr = np.asarray(X_train_processed, dtype=float)
Xval = np.asarray(X_val_processed, dtype=float)
Xte = np.asarray(X_test_processed, dtype=float)

ytr = y_train.to_numpy(dtype=float)
yval = y_val.to_numpy(dtype=float)
yte = y_test.to_numpy(dtype=int)

print("Processed training shape:", Xtr.shape)
print("Processed validation shape:", Xval.shape)
print("Processed testing shape:", Xte.shape)

print("Missing values:", np.isnan(Xtr).sum())

# Add bias column
X_train_scratch = np.c_[np.ones(len(Xtr)), Xtr]
X_val_scratch = np.c_[np.ones(len(Xval)), Xval]
X_test_scratch = np.c_[np.ones(len(Xte)), Xte]

def logistic_loss(X, y, theta, lam):

    z = X @ theta

    loss = np.mean(
        np.logaddexp(0, z) - y * z
    )

    penalty = (
        lam / (2 * len(y))
    ) * np.sum(theta[1:] ** 2)

    return loss + penalty


def train_logistic(lr, lam, max_epochs=1500,
                   patience=100, verbose=False):

    theta = np.zeros(X_train_scratch.shape[1])

    m = len(ytr)

    beta1 = 0.9
    beta2 = 0.999
    epsilon = 1e-8

    mt = np.zeros_like(theta)
    vt = np.zeros_like(theta)

    best_loss = float('inf')
    best_theta = theta.copy()
    wait = 0

    history = {
        'train_loss': [],
        'val_loss': [],
        'train_accuracy': [],
        'val_accuracy': []
    }

    for epoch in range(1, max_epochs + 1):

        # Forward propagation
        prob = expit(X_train_scratch @ theta)

        # Gradient
        gradient = (
            X_train_scratch.T @ (prob - ytr)
        ) / m

        gradient[1:] += (
            lam / m
        ) * theta[1:]

        # Adam optimization
        mt = beta1 * mt + (1-beta1) * gradient
        vt = beta2 * vt + (1-beta2) * gradient**2

        mt_hat = mt / (1-beta1**epoch)
        vt_hat = vt / (1-beta2**epoch)

        theta -= lr * mt_hat / (
            np.sqrt(vt_hat) + epsilon
        )

        # Training predictions
        train_prob = expit(
            X_train_scratch @ theta
        )

        # Validation predictions
        val_prob = expit(
            X_val_scratch @ theta
        )

        # Loss
        train_loss = logistic_loss(
            X_train_scratch, ytr, theta, lam
        )

        val_loss = logistic_loss(
            X_val_scratch, yval, theta, lam
        )

        # Accuracy
        train_acc = accuracy_score(
            ytr, (train_prob >= 0.5).astype(int)
        ) * 100

        val_acc = accuracy_score(
            yval, (val_prob >= 0.5).astype(int)
        ) * 100

        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['train_accuracy'].append(train_acc)
        history['val_accuracy'].append(val_acc)

        # Early stopping based on validation loss
        if val_loss < best_loss - 1e-7:

            best_loss = val_loss
            best_theta = theta.copy()
            wait = 0

        else:
            wait += 1

        if verbose and (
            epoch == 1 or epoch % 10 == 0
        ):
            print(
                f"Epoch {epoch:4d} | "
                f"Train Loss: {train_loss:.4f} | "
                f"Train Accuracy: {train_acc:.2f}% | "
                f"Val Loss: {val_loss:.4f} | "
                f"Val Accuracy: {val_acc:.2f}%"
            )

        if wait >= patience:
            if verbose:
                print("Early stopping at epoch:", epoch)
            break

    return best_theta, history, best_loss

learning_rates = [0.001, 0.003, 0.01]
regularization_values = [0.001, 0.01, 0.1, 1.0]

best_val_loss = float('inf')

best_lr = None
best_lam = None

print("Starting hyperparameter tuning...\n")

for lr in learning_rates:

    for lam in regularization_values:

        theta, history, val_loss = train_logistic(
            lr, lam,
            max_epochs=1500,
            patience=100
        )

        print(
            f"LR: {lr} | Lambda: {lam} | "
            f"Validation Loss: {val_loss:.5f}"
        )

        if val_loss < best_val_loss:

            best_val_loss = val_loss
            best_lr = lr
            best_lam = lam

print("\nBest Learning Rate:", best_lr)
print("Best Regularization:", best_lam)
print("Best Validation Loss:", best_val_loss)

print("Training final logistic regression model...\n")

w, history, best_val_loss = train_logistic(
    best_lr,
    best_lam,
    max_epochs=2000,
    patience=150,
    verbose=True
)

# Save training history
history_df = pd.DataFrame(history)

history_df.insert(
    0, 'Epoch',
    range(1, len(history_df) + 1)
)

history_df.to_csv(
    'scratch_logistic_history.csv',
    index=False
)

print("\nTraining history saved!")

plt.figure(figsize=(9, 5))

plt.plot(history['train_loss'], label='Training Loss')
plt.plot(history['val_loss'], label='Validation Loss')

plt.xlabel('Epoch')
plt.ylabel('Binary Cross-Entropy Loss')
plt.title('Scratch Logistic Regression - Loss')

plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('scratch_loss.png', dpi=300)
plt.show()

plt.figure(figsize=(9, 5))

plt.plot(history['train_accuracy'], label='Training Accuracy')
plt.plot(history['val_accuracy'], label='Validation Accuracy')

plt.xlabel('Epoch')
plt.ylabel('Accuracy (%)')
plt.title('Scratch Logistic Regression - Accuracy')

plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('scratch_accuracy.png', dpi=300)
plt.show()

# Test predictions
test_prob_scratch = expit(
    X_test_scratch @ w
)

test_pred_scratch = (
    test_prob_scratch >= 0.5
).astype(int)

print("SCRATCH LOGISTIC REGRESSION")
print("--------------------------------")

print("Test Accuracy:",
      accuracy_score(yte, test_pred_scratch) * 100)

print("ROC-AUC:",
      roc_auc_score(yte, test_prob_scratch))

print("\nClassification Report:")

print(classification_report(
    yte, test_pred_scratch
))

print("\nConfusion Matrix:")

cm = confusion_matrix(
    yte, test_pred_scratch
)

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Scratch Logistic Regression")
plt.show()

C_values = [0.01, 0.1, 1, 10, 100]

best_C = None
best_val_accuracy = 0

for C in C_values:

    model = LogisticRegression(
        C=C,
        max_iter=2000,
        solver='lbfgs'
    )

    model.fit(Xtr, ytr)

    val_pred = model.predict(Xval)

    val_accuracy = accuracy_score(
        yval, val_pred
    )

    print(
        f"C: {C} | "
        f"Validation Accuracy: {val_accuracy*100:.2f}%"
    )

    if val_accuracy > best_val_accuracy:

        best_val_accuracy = val_accuracy
        best_C = C

print("\nBest C:", best_C)
print("Best Validation Accuracy:", best_val_accuracy*100)

sk_lr = LogisticRegression(
    C=best_C,
    max_iter=2000,
    solver='lbfgs'
)

sk_lr.fit(Xtr, ytr)

sk_prob = sk_lr.predict_proba(Xte)[:, 1]

sk_pred = (sk_prob >= 0.5).astype(int)

print("\nSCIKIT-LEARN LOGISTIC REGRESSION")
print("--------------------------------")

print("Test Accuracy:",
      accuracy_score(yte, sk_pred)*100)

print("ROC-AUC:",
      roc_auc_score(yte, sk_prob))

print("\nClassification Report:")

print(classification_report(yte, sk_pred))

print("Confusion Matrix:")

sns.heatmap(
    confusion_matrix(yte, sk_pred),
    annot=True,
    fmt='d',
    cmap='Greens'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Scikit-learn Logistic Regression")
plt.show()

rf_configs = [
    {'max_depth': 20, 'min_samples_leaf': 1},
    {'max_depth': 20, 'min_samples_leaf': 3},
    {'max_depth': None, 'min_samples_leaf': 1},
    {'max_depth': None, 'min_samples_leaf': 3}
]

best_rf = None
best_rf_accuracy = 0

print("Random Forest hyperparameter tuning\n")

for config in rf_configs:

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=config['max_depth'],
        min_samples_leaf=config['min_samples_leaf'],
        random_state=42,
        n_jobs=-1
    )

    model.fit(Xtr, ytr)

    val_pred = model.predict(Xval)

    val_accuracy = accuracy_score(
        yval, val_pred
    )

    print(
        f"Configuration: {config} | "
        f"Validation Accuracy: {val_accuracy*100:.2f}%"
    )

    if val_accuracy > best_rf_accuracy:

        best_rf_accuracy = val_accuracy
        best_rf = model

print("\nBest Random Forest Validation Accuracy:",
      best_rf_accuracy*100)

rf = best_rf

rf_prob = rf.predict_proba(Xte)[:, 1]
rf_pred = (rf_prob >= 0.5).astype(int)

print("\nRANDOM FOREST RESULTS")
print("--------------------------------")

print("Test Accuracy:",
      accuracy_score(yte, rf_pred)*100)

print("ROC-AUC:",
      roc_auc_score(yte, rf_prob))

print("\nClassification Report:")

print(classification_report(yte, rf_pred))

sns.heatmap(
    confusion_matrix(yte, rf_pred),
    annot=True,
    fmt='d',
    cmap='Oranges'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Random Forest Confusion Matrix")
plt.show()

feature_names = preprocessor.get_feature_names_out()

importance = pd.Series(
    rf.feature_importances_,
    index=feature_names
).sort_values(ascending=False)

print("Top 10 Important Features:")
print(importance.head(10))

plt.figure(figsize=(9, 6))

importance.head(15).sort_values().plot(
    kind='barh'
)

plt.xlabel("Feature Importance")
plt.ylabel("Features")
plt.title("Random Forest - Feature Importance")

plt.tight_layout()
plt.savefig('feature_importance.png', dpi=300)
plt.show()

results = pd.DataFrame({

    'Model': [
        'Scratch Logistic Regression',
        'Scikit-learn Logistic Regression',
        'Random Forest'
    ],

    'Accuracy (%)': [
        accuracy_score(yte, test_pred_scratch)*100,
        accuracy_score(yte, sk_pred)*100,
        accuracy_score(yte, rf_pred)*100
    ],

    'Precision (%)': [
        precision_score(yte, test_pred_scratch)*100,
        precision_score(yte, sk_pred)*100,
        precision_score(yte, rf_pred)*100
    ],

    'Recall (%)': [
        recall_score(yte, test_pred_scratch)*100,
        recall_score(yte, sk_pred)*100,
        recall_score(yte, rf_pred)*100
    ],

    'F1 Score (%)': [
        f1_score(yte, test_pred_scratch)*100,
        f1_score(yte, sk_pred)*100,
        f1_score(yte, rf_pred)*100
    ],

    'ROC-AUC': [
        roc_auc_score(yte, test_prob_scratch),
        roc_auc_score(yte, sk_prob),
        roc_auc_score(yte, rf_prob)
    ]
})

print(results.round(3))

results.set_index('Model')[
    ['Accuracy (%)', 'Precision (%)', 'Recall (%)', 'F1 Score (%)']
].plot(
    kind='bar',
    figsize=(11, 6)
)

plt.ylabel("Performance (%)")
plt.title("Comparison of Classification Models")
plt.xticks(rotation=15)
plt.legend(loc='lower right')
plt.grid(axis='y')
plt.tight_layout()
plt.savefig('model_comparison.png', dpi=300)
plt.show()

from scipy.stats import pointbiserialr

correlations = {}

numeric_data = data.select_dtypes(
    include=np.number
).drop(columns=['cardio'], errors='ignore')

for col in numeric_data.columns:

    if numeric_data[col].nunique() < 2:
        continue

    r, p = pointbiserialr(
        y,
        numeric_data[col]
    )

    correlations[col] = r

    print(
        f"{col:22s} | "
        f"Correlation: {r:.4f} | "
        f"P-value: {p:.4e}"
    )

corr_df = pd.DataFrame.from_dict(
    correlations,
    orient='index',
    columns=['Correlation']
)

plt.figure(figsize=(7, 6))

sns.heatmap(
    corr_df,
    annot=True,
    cmap='coolwarm',
    center=0,
    fmt='.3f'
)

plt.title('Feature Correlation with Cardio')
plt.tight_layout()
plt.savefig('correlation_heatmap.png', dpi=300)
plt.show()

results.to_csv(
    'cardio_model_comparison.csv',
    index=False
)

history_df.to_csv(
    'scratch_logistic_history.csv',
    index=False
)

print("All results saved successfully!")

print("\nGenerated files:")
print("1. scratch_logistic_history.csv")
print("2. cardio_model_comparison.csv")
print("3. scratch_loss.png")
print("4. scratch_accuracy.png")
print("5. feature_importance.png")
print("6. model_comparison.png")
print("7. correlation_heatmap.png")

print("\nTotal execution time:",
      round(time.time()-start, 2), "seconds")